<?php
/*
 * Render Partial Left Menu
 * 
 */
$this->menu = array(
    array('label' => 'List All', 'url' => array('index'), 'visible' => true),
    array('label' => 'Create New', 'url' => array('create'), 'visible' => true),
);

?>
